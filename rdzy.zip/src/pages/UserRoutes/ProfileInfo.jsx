
import {React} from "react";
import Base from "../../components/Base";
const ProfileInfo=()=>{
    return(
            

            <Base>
                <div>
                <h1>    welcome to user profile page</h1>

                </div>
            </Base>
    )
}

export default ProfileInfo;