
import {React} from "react";
import Base from "../../components/Base";
const Userdashboard=()=>{
    return(
            

            <Base>
                <div>
                <h1>    welcome to user dashboard</h1>

                </div>
            </Base>
    )
}

export default Userdashboard;