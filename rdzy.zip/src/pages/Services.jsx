import Base from "../components/Base";

const Services=()=>{

    return(
        <Base>
            <h1>this is service page</h1>
        </Base>
    );
}

export default Services;